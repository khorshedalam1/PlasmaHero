package com.khurshed.plasmahero;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Login extends AppCompatActivity {
    EditText email, pass;
    TextView sign_up, terms;
    SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        sessionManager = new SessionManager(this);
        //sessionManager.checkLogin();
        email = findViewById(R.id.user_email);
        pass = findViewById(R.id.user_pass);
        sign_up = findViewById(R.id.signUp);
        terms = findViewById(R.id.terms);
        terms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Login.this, TermsOfService.class));
            }
        });


        sign_up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Login.this, Signup.class));

            }
        });



    }

    public void loginNow(View view) {
        String Email = email.getText().toString();
        String Pass = pass.getText().toString();
        Toast.makeText(this, "Loading...", Toast.LENGTH_SHORT).show();
        useerlogin(Email,Pass);


    }

    public void useerlogin(String email, String pass)
    {
        String url = "https://projecttech.xyz/plasma_hero_by_khurshed/login.php?email="+email+"&password="+pass;
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = jsonObject.getJSONArray("result");
                    JSONObject userObject = jsonArray.getJSONObject(0);
                    if (!userObject.getString("error").equalsIgnoreCase("no")) {

                        Toast.makeText(Login.this, "Data Does not Matched", Toast.LENGTH_SHORT).show();

                    } else {

                        startActivity( new Intent(Login.this,DeshboardActivity.class));
                        sessionManager.createSession(email,pass);
                        Toast.makeText(Login.this, "Login Successful", Toast.LENGTH_SHORT).show();
                        finish();
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }
        );
        requestQueue.add(stringRequest);
    }
}