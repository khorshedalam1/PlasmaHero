package com.khurshed.plasmahero;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class CallDonor extends AppCompatActivity {
    TextView textView;
    Button call;
    Date d;
    SessionManager sessionManager;
    String nPhone, user_name, blood_group, address;
    String Phone;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_call_donor);
        Intent intent = getIntent();
        nPhone = intent.getStringExtra("phone_number");
        user_name = intent.getStringExtra("user_name");
        blood_group = intent.getStringExtra("blood_group");
        address = intent.getStringExtra("address");


        textView = findViewById(R.id.textview);
        textView.setText(nPhone);
        call = findViewById(R.id.phoneCall);
        callDonor(nPhone);
        getPhoneNumberbyEmail();
        finish();
        //insertData(Phone); // this is for saving who is calling so that i can show up details in recent contacts in MYPOST activity


    }
    public void callDonor(String phone)
    {
        try
        {
            if(Build.VERSION.SDK_INT > 22)
            {
                if (ActivityCompat.checkSelfPermission(CallDonor.this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                    // TODO: Consider calling
                    ActivityCompat.requestPermissions((Activity) CallDonor.this, new String[]{Manifest.permission.CALL_PHONE}, 101);
                    return;
                }
                Intent callIntent = new Intent(Intent.ACTION_CALL);
                callIntent.setData(Uri.parse("tel:" + phone));
                startActivity(callIntent);

            }
            else {
                Intent callIntent = new Intent(Intent.ACTION_CALL);
                callIntent.setData(Uri.parse("tel:" + phone));
                startActivity(callIntent);
            }
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }

    public void getPhoneNumberbyEmail()
    {
        sessionManager = new SessionManager(this);
        sessionManager.checkLogin();
        HashMap<String, String> user = sessionManager.getUserDetail();
        String nemail1 = user.get(sessionManager.EMAIL);
        String url = "http://projecttech.xyz/plasma_hero_by_khurshed/update_phone.php?email=" + nemail1;

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onResponse(String response) {
                Log.d("Res=", url);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = jsonObject.getJSONArray("Result");
                    JSONObject data = jsonArray.getJSONObject(0);

//                    data.getInt("id");
//                    data.getString("student_name");
//                    data.getString("ssc_roll");
//                    data.getString("hsc_roll");
//                    data.getString("student_reg");

                   Phone =data.getString("phone_number");
                    Log.d("TAG", "onResponse: "+Phone);

                    insertData(Phone);


                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(CallDonor.this, "Failed", Toast.LENGTH_SHORT).show();

            }
        });

        requestQueue.add(stringRequest);


    }

    public void insertData(String phone)
    {
        d = new Date();
        String date = d.toString();
        sessionManager = new SessionManager(this);
        sessionManager.checkLogin();
        HashMap<String, String> user = sessionManager.getUserDetail();
        String nemail1 = user.get(sessionManager.EMAIL);
        String url = "http://projecttech.xyz/plasma_hero_by_khurshed/donation_history.php";
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(CallDonor.this, "Success", Toast.LENGTH_SHORT).show();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(CallDonor.this, "Check your Internet Connection.", Toast.LENGTH_SHORT).show();
            }
        })
        {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {


                Map<String, String> stringStringMap = new HashMap<>();

                stringStringMap.put("user_name", user_name);
                //stringStringMap.put("email", nemail1);
                stringStringMap.put("phone_number", nPhone);
                stringStringMap.put("blood_group", blood_group);
                stringStringMap.put("address", address);
                stringStringMap.put("date", date);
                stringStringMap.put("call_made_by", phone);
                stringStringMap.put("caller_email", nemail1);



                return stringStringMap;
            }
        };
        requestQueue.add(stringRequest);
    }







}