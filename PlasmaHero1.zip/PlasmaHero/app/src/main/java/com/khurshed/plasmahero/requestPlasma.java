package com.khurshed.plasmahero;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.firebase.messaging.FirebaseMessaging;
import com.synnapps.carouselview.CarouselView;
import com.synnapps.carouselview.ImageListener;

import java.util.HashMap;
import java.util.Map;

public class requestPlasma extends AppCompatActivity {

    SessionManager sessionManager;
    EditText Donor_name, phone_number, blood_group, address;
    String status = "Need Plasma";
    TextView postView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_request_plasma);
        Donor_name = findViewById(R.id.your_name);
        phone_number = findViewById(R.id.your_phone);
        blood_group = findViewById(R.id.your_bloodgroup);
        address = findViewById(R.id.your_location);
        postView = findViewById(R.id.postView);
        FirebaseMessaging.getInstance().subscribeToTopic("all");
        postView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(requestPlasma.this, MyPosts.class));
                finish();
            }
        });

    }

    public void RequestHelp(View view) {
        requestPlasmaFromDonor();
        sendNotificationtoall();

    }
    public void requestPlasmaFromDonor()
    {
        sessionManager = new SessionManager(this);
        sessionManager.checkLogin();
        HashMap<String, String> user = sessionManager.getUserDetail();
        String nEmail = user.get(sessionManager.EMAIL);
        String url = "http://projecttech.xyz/plasma_hero_by_khurshed/post_as_donor.php";
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(requestPlasma.this, "Success", Toast.LENGTH_SHORT).show();

                startActivity(new Intent(requestPlasma.this, DeshboardActivity.class));
                finish();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(requestPlasma.this, "Check your Internet Connection.", Toast.LENGTH_SHORT).show();
            }
        })
        {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {


                Map<String, String> stringStringMap = new HashMap<>();

                stringStringMap.put("user_name", Donor_name.getText().toString());
                stringStringMap.put("email", nEmail);
                stringStringMap.put("status", status);
                stringStringMap.put("blood_group", blood_group.getText().toString());
                stringStringMap.put("address", address.getText().toString());
                stringStringMap.put("phone_number", phone_number.getText().toString());





                //stringStringMap.put("token", token);




                return stringStringMap;
            }
        };
        requestQueue.add(stringRequest);
    }
    public void sendNotificationtoall()
    {
        String name = Donor_name.getText().toString();
        String Address = address.getText().toString();
        String bloodgroup = blood_group.getText().toString();
        String title = "Plasma Request";
        String body = name+" is looking for Plasma Heroes with "+bloodgroup+" Blood group in "+Address;
        Log.d("TAG", "sendNotificationtoall: "+body);


        FcmNotificationsSender notificationsSender = new FcmNotificationsSender("/topics/all",title,body, getApplicationContext(), requestPlasma.this);
        notificationsSender.SendNotifications();

    }
}