package com.khurshed.plasmahero;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MyAdapter2 extends RecyclerView.Adapter<MyAdapter2.CustomAdapterHolder>{
    private List<Model> arrayListModel;
    private Context context;
    public MyAdapter2(List<Model> arrayListModel, Context context) {
        this.arrayListModel = arrayListModel;
        this.context = context;
    }

    @NonNull
    @Override
    public MyAdapter2.CustomAdapterHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.my_posts,parent,false);
        return new MyAdapter2.CustomAdapterHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyAdapter2.CustomAdapterHolder holder, int position) {
        Model model = arrayListModel.get(position);
        holder.userName.setText(model.getUser_name());
        // holder.email.setText(model.getEmail());
        holder.blood_group.setText(model.getBlood_group());
        holder.status.setText(model.getStatus());
        holder.address.setText(model.getLocation());
        holder.phone.setText(model.getPhone_number());

        holder.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(holder.delete.getContext(),DeletePost.class);
                intent.putExtra("phone_number", holder.phone.getText().toString());
                intent.putExtra("user_name", holder.userName.getText().toString());
                intent.putExtra("blood_group", holder.blood_group.getText().toString());
                intent.putExtra("address", holder.address.getText().toString());
                holder.delete.getContext().startActivity(intent);


            }
        });

    }

    @Override
    public int getItemCount() {
        return arrayListModel.size();
    }

    public class CustomAdapterHolder extends RecyclerView.ViewHolder {
        TextView userName,email,blood_group,phone,status,address;
        Button delete;
        public CustomAdapterHolder(@NonNull View itemView) {
            super(itemView);
            userName = itemView.findViewById(R.id.recycleUser);
            //email = itemView.findViewById(R.id.recycleEmail);
            blood_group = itemView.findViewById(R.id.recycleBlood);
            status = itemView.findViewById(R.id.recycleStatus);
            phone = itemView.findViewById(R.id.recyclePhone);
            address = itemView.findViewById(R.id.recyclelocation);

            delete = itemView.findViewById(R.id.deletebtn);






        }
    }
}
