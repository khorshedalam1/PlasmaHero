package com.khurshed.plasmahero;

public class Model {
    String user_name, email, status, phone_number,blood_group,Location;

    public Model(String user_name, String email, String status, String phone_number, String blood_group, String location) {
        this.user_name = user_name;
        this.email = email;
        this.status = status;
        this.phone_number = phone_number;
        this.blood_group = blood_group;
        Location = location;
    }

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getPhone_number() {
        return phone_number;
    }

    public void setPhone_number(String phone_number) {
        this.phone_number = phone_number;
    }

    public String getBlood_group() {
        return blood_group;
    }

    public void setBlood_group(String blood_group) {
        this.blood_group = blood_group;
    }

    public String getLocation() {
        return Location;
    }

    public void setLocation(String location) {
        Location = location;
    }
}
