package com.khurshed.plasmahero;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class AllDonorLists extends AppCompatActivity {
    RecyclerView recyclerView;
    //Button search;
    EditText searchfield;
    MyAdapter adapter;
    List<Model> modelList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_donor_lists);
        //search = findViewById(R.id.searchDonor);
        searchfield = findViewById(R.id.search);
        searchfield.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                filter(s.toString());

            }
        });
        modelList = new ArrayList<>();
        recyclerView = findViewById(R.id.recyclerView1);
        recyclerView.setAdapter(adapter);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(AllDonorLists.this));
        showAllDonor();
    }
    public void filter(String text) //search button er kaj new list e add kora
    {
        ArrayList<Model> modelArrayList = new ArrayList<>();
        for(Model model: modelList)
        {
            if(model.getLocation().toLowerCase().contains(text.toLowerCase())){
                modelArrayList.add(model);

            }
            adapter.filteredList(modelArrayList);
        }
    }

    public void showAllDonor()
    {
        String url="http://projecttech.xyz/plasma_hero_by_khurshed/show_donor_lists.php?status=Available";
        Log.d("TAG", "datashow: "+url);

        RequestQueue requestQueue = Volley.newRequestQueue(AllDonorLists.this);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                Log.d("Res=", url);
                ;
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = jsonObject.getJSONArray("Result");
                    Log.d("TAG", "onResponse: "+jsonArray);

                    for(int i=0; i<jsonArray.length();i++){
                        JSONObject data = jsonArray.getJSONObject(i);
                        Log.d("TAG", "onResponse1: "+data);
                        modelList.add(new Model(
                                data.getString("user_name"),
                                data.getString("email"),
                                data.getString("status"),
                                data.getString("phone_number"),
                                data.getString("blood_group"),
                                data.getString("address")
                                ));
                        //Toast.makeText(Pending.this, ""+modelList, Toast.LENGTH_SHORT).show();
                    }
                    adapter = new MyAdapter(modelList,AllDonorLists.this);
                    recyclerView.setAdapter(adapter);
                    adapter.notifyDataSetChanged();

                }catch (JSONException e){
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(AllDonorLists.this, "Error", Toast.LENGTH_SHORT).show();
            }
        }
        );

        requestQueue.add(stringRequest);
    }
}