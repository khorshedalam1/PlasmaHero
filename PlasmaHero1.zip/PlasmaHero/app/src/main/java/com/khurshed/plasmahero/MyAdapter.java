package com.khurshed.plasmahero;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.CustomAdapterHolder>
{
    private List<Model> arrayListModel;
    private Context context;
    SessionManager sessionManager;
    public MyAdapter(List<Model> arrayListModel, Context context) {
        this.arrayListModel = arrayListModel;
        this.context = context;
    }

    @NonNull
    @Override
    public MyAdapter.CustomAdapterHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.single_row,parent,false);
        return new CustomAdapterHolder(view); //layout set korlam
    }

    @Override
    public void onBindViewHolder(@NonNull MyAdapter.CustomAdapterHolder holder, int position) {
        Model model = arrayListModel.get(position);
        holder.userName.setText(model.getUser_name());
       // holder.email.setText(model.getEmail());
        holder.blood_group.setText(model.getBlood_group());
        holder.status.setText(model.getStatus());
        holder.address.setText(model.getLocation());
        holder.phone.setText(model.getPhone_number());
        holder.report.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(holder.call.getContext(),ReportFrauds.class);

                holder.report.getContext().startActivity(intent);

            }
        });
        holder.call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(holder.call.getContext(),CallDonor.class);

                intent.putExtra("phone_number", holder.phone.getText().toString());
                intent.putExtra("user_name", holder.userName.getText().toString());
                intent.putExtra("blood_group", holder.blood_group.getText().toString());
                intent.putExtra("address", holder.address.getText().toString());
                //ekhane donor er info putextra korbo.
                holder.call.getContext().startActivity(intent); //intent korlam callDonor activity te
            }
        });



    }
    public void filteredList(ArrayList<Model> modelArrayList) //search result er jnno
    {
        arrayListModel = modelArrayList;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return arrayListModel.size();
    }

    public class CustomAdapterHolder extends RecyclerView.ViewHolder {
        TextView userName,email,blood_group,phone,status,address;
        Button call, report; //layout er joto file shob initialize korechi
        public CustomAdapterHolder(@NonNull View itemView) {
            super(itemView);
            userName = itemView.findViewById(R.id.recycleUser);
            //email = itemView.findViewById(R.id.recycleEmail);
            blood_group = itemView.findViewById(R.id.recycleBlood);
            status = itemView.findViewById(R.id.recycleStatus);
            phone = itemView.findViewById(R.id.recyclePhone);
            address = itemView.findViewById(R.id.recyclelocation);
            call = itemView.findViewById(R.id.call);
            report = itemView.findViewById(R.id.reportasfraud);

       



        }
    }
}
