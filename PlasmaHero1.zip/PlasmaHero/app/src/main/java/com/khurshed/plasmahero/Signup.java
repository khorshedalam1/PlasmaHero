package com.khurshed.plasmahero;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Signup extends AppCompatActivity {
    EditText user_name, email, pass, phone, blood;
    TextView login,terms;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        user_name = findViewById(R.id.user_name);
        email = findViewById(R.id.user_email);
        pass = findViewById(R.id.user_pass);
        phone = findViewById(R.id.user_phone);
        blood = findViewById(R.id.user_bloodgroup);
        login = findViewById(R.id.login);
        terms = findViewById(R.id.terms);
        terms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity( new Intent(Signup.this, TermsOfService.class));
            }
        });
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity( new Intent(Signup.this, Login.class));
                finish();
            }
        });
    }

    public void signupNow(View view) {

        String Email = email.getText().toString();
        String Phone = phone.getText().toString();
        String Password = pass.getText().toString();
        String USER = user_name.getText().toString();
        String BloodGroup = blood.getText().toString();



        if (Email.isEmpty() || Phone.isEmpty() || Password.isEmpty() || USER.isEmpty() || BloodGroup.isEmpty())
        {
            Toast.makeText(this, "Fields can not be empty", Toast.LENGTH_SHORT).show();
        }
        else
        {
            checkifEmailUsedAnywhere(Email);

            //insertData();
            //startActivity(new Intent(this, Login.class));
            //finish();
        }




    }
    public void insertData()
    {
        String url = "http://projecttech.xyz/plasma_hero_by_khurshed/signup.php";
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(Signup.this, "Success", Toast.LENGTH_SHORT).show();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Signup.this, "Check your Internet Connection.", Toast.LENGTH_SHORT).show();
            }
        })
        {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {


                Map<String, String> stringStringMap = new HashMap<>();

                stringStringMap.put("user_name", user_name.getText().toString());
                stringStringMap.put("email", email.getText().toString());
                stringStringMap.put("password", pass.getText().toString());
                stringStringMap.put("phone_number", phone.getText().toString());
                stringStringMap.put("blood_group", blood.getText().toString());





                return stringStringMap;
            }
        };
        requestQueue.add(stringRequest);
    }

    public void checkifEmailUsedAnywhere(String email)
    {
        String url = "http://projecttech.xyz/plasma_hero_by_khurshed/check_existing_user_data.php?email="+email;
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = jsonObject.getJSONArray("result");
                    JSONObject userObject = jsonArray.getJSONObject(0);
                    if (!userObject.getString("error").equalsIgnoreCase("no")) {
                        insertData();
                        startActivity( new Intent(Signup.this, Login.class));
                        finish();

                    } else {

                        Toast.makeText(Signup.this, "Email is already in use. Try Login", Toast.LENGTH_SHORT).show();

                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }
        );
        requestQueue.add(stringRequest);
    }
}