package com.khurshed.plasmahero;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class DeletePost extends AppCompatActivity {
    String nPhone, user_name, blood_group, address1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_post);
        Intent intent = getIntent();
        nPhone = intent.getStringExtra("phone_number");
        user_name = intent.getStringExtra("user_name");
        blood_group = intent.getStringExtra("blood_group");
        address1 = intent.getStringExtra("address");
        deletemypost(nPhone);
    }
    
    public void deletemypost(String phone)
    {
        String url = "http://projecttech.xyz/plasma_hero_by_khurshed/delete_post.php?phone_number="+phone;
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        Log.d("TAG", "deletemypost: "+url);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(DeletePost.this, "Deleted", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(DeletePost.this, DeshboardActivity.class));
                finish();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(DeletePost.this, "Check Internet Connection", Toast.LENGTH_SHORT).show();
            }
        })
        {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {


                Map<String, String> stringStringMap = new HashMap<>();

                //stringStringMap.put("user_name", name);
                //stringStringMap.put("email", nemail1);
                stringStringMap.put("phone_number", phone);
               // stringStringMap.put("blood_group", blood);
                //stringStringMap.put("address", address);
               // stringStringMap.put("date", date);
                //stringStringMap.put("call_made_by", phone);
                //stringStringMap.put("caller_email", nemail1);



                return stringStringMap;
            }
        };
        requestQueue.add(stringRequest);
    }
}