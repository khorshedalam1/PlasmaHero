package com.khurshed.plasmahero;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class RecentContacts extends AppCompatActivity {
    RecyclerView recyclerView;
    SessionManager sessionManager;

    MyAdapter3 adapter2;
    List<Model1> modelList2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recent_contacts);
        modelList2 = new ArrayList<>();
        recyclerView = findViewById(R.id.recyclerView4);
        recyclerView.setAdapter(adapter2);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(RecentContacts.this));
        my_posts();


    }
    public void my_posts()

    {
        sessionManager = new SessionManager(this);
        sessionManager.checkLogin();
        HashMap<String, String> user = sessionManager.getUserDetail();
        String nemail1 = user.get(sessionManager.EMAIL);
        String url="http://projecttech.xyz/plasma_hero_by_khurshed/show_contact_history.php?caller_email="+nemail1;
        Log.d("TAG", "datashow: "+url);

        RequestQueue requestQueue = Volley.newRequestQueue(RecentContacts.this);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                Log.d("Res=", url);
                ;
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = jsonObject.getJSONArray("Result");
                    Log.d("TAG", "onResponse: "+jsonArray);

                    for(int i=0; i<jsonArray.length();i++){
                        JSONObject data = jsonArray.getJSONObject(i);
                        Log.d("TAG", "onResponse1: "+data);
                        modelList2.add(new Model1(
                                data.getString("id"),
                                data.getString("user_name"),
                                data.getString("blood_group"),
                                data.getString("phone_number"),
                                data.getString("Address"),
                                data.getString("date"),
                                data.getString("caller_email"),
                                data.getString("call_made_by")
                        ));
                        //Toast.makeText(Pending.this, ""+modelList, Toast.LENGTH_SHORT).show();
                    }
                    adapter2 = new MyAdapter3(modelList2,RecentContacts.this);
                    recyclerView.setAdapter(adapter2);
                    adapter2.notifyDataSetChanged();

                }catch (JSONException e){
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(RecentContacts.this, "Error", Toast.LENGTH_SHORT).show();
            }
        }
        );

        requestQueue.add(stringRequest);
    }

}