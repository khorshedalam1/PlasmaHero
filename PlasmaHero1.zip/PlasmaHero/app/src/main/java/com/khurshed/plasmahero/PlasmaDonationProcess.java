package com.khurshed.plasmahero;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;

import com.synnapps.carouselview.CarouselView;
import com.synnapps.carouselview.ImageListener;

public class PlasmaDonationProcess extends AppCompatActivity {
    CarouselView carouselView;

    private int [] mImages = new int[] {
            R.drawable.processfirst,
            R.drawable.processsec,
            R.drawable.processthirddddddd,
            R.drawable.processfourrrrrrr,
            R.drawable.processfiveee

    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_plasma_donation_process);

        carouselView = (CarouselView) findViewById(R.id.carousel4);
        carouselView.setPageCount(mImages.length);
        carouselView.setImageListener(new ImageListener() {
            @Override
            public void setImageForPosition(int position, ImageView imageView) {

                imageView.setImageResource(mImages[position]);
            }
        });
    }
}