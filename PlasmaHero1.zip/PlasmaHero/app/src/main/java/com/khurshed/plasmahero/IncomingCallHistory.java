package com.khurshed.plasmahero;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class IncomingCallHistory extends AppCompatActivity {

    RecyclerView recyclerView;
    String phone;
    SessionManager sessionManager;
    Adapter4 adapter2;
    List<Model1> modelList2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_incoming_call_history);


        modelList2 = new ArrayList<>();
        recyclerView = findViewById(R.id.recylerView5);
        recyclerView.setAdapter(adapter2);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(IncomingCallHistory.this));

        updatePhone();
    }
    public void updatePhone()
    {
        sessionManager = new SessionManager(this);
        sessionManager.checkLogin();
        HashMap<String, String> user = sessionManager.getUserDetail();
        String email1 = user.get(sessionManager.EMAIL);
        String url = "http://projecttech.xyz/plasma_hero_by_khurshed/update_phone_call.php?email=" + email1;

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onResponse(String response) {
                Log.d("Res=", url);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = jsonObject.getJSONArray("Result");
                    JSONObject data = jsonArray.getJSONObject(0);

//                    data.getInt("id");
//                    data.getString("student_name");
//                    data.getString("ssc_roll");
//                    data.getString("hsc_roll");
//                    data.getString("student_reg");

                   phone = data.getString("phone_number");

                    my_posts(phone);



                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(IncomingCallHistory.this, "Failed", Toast.LENGTH_SHORT).show();

            }
        });

        requestQueue.add(stringRequest);

    }
    public void my_posts(String phn)

    {
        sessionManager = new SessionManager(this);
        sessionManager.checkLogin();
        //HashMap<String, String> user = sessionManager.getUserDetail();
        //String nemail1 = user.get(sessionManager.EMAIL);
        String url="http://finalproject.xyz/plasma_hero_by_khurshed/incoming_call_history.php?phone_number="+phn;
        Log.d("TAG", "datashow: "+url);

        RequestQueue requestQueue = Volley.newRequestQueue(IncomingCallHistory.this);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                Log.d("Res=", url);
                ;
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = jsonObject.getJSONArray("Result");
                    Log.d("TAG", "onResponse: "+jsonArray);

                    for(int i=0; i<jsonArray.length();i++){
                        JSONObject data = jsonArray.getJSONObject(i);
                        Log.d("TAG", "onResponse1: "+data);
                        modelList2.add(new Model1(
                                data.getString("id"),
                                data.getString("user_name"),
                                data.getString("blood_group"),
                                data.getString("phone_number"),
                                data.getString("Address"),
                                data.getString("date"),
                                data.getString("caller_email"),
                                data.getString("call_made_by")
                        ));
                        //Toast.makeText(Pending.this, ""+modelList, Toast.LENGTH_SHORT).show();
                    }
                    adapter2 = new Adapter4(modelList2,IncomingCallHistory.this);
                    recyclerView.setAdapter(adapter2);
                    adapter2.notifyDataSetChanged();

                }catch (JSONException e){
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(IncomingCallHistory.this, "Error", Toast.LENGTH_SHORT).show();
            }
        }
        );

        requestQueue.add(stringRequest);
    }

}