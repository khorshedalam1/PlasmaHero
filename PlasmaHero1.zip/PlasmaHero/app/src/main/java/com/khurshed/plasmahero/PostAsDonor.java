package com.khurshed.plasmahero;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.synnapps.carouselview.CarouselView;
import com.synnapps.carouselview.ImageListener;

import java.util.HashMap;
import java.util.Map;

public class PostAsDonor extends AppCompatActivity {
    CarouselView carouselView;
    SessionManager sessionManager;
    EditText Donor_name, phone_number, blood_group, address;
    String status = "Available";

    private int [] mImages = new int[] {
            R.drawable.herothird,
            R.drawable.herofirst,
            R.drawable.herosecend

    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_as_donor);
        carouselView = (CarouselView) findViewById(R.id.carousel);
        carouselView.setPageCount(mImages.length);
        carouselView.setImageListener(new ImageListener() {
            @Override
            public void setImageForPosition(int position, ImageView imageView) {
                imageView.setImageResource(mImages[position]);
            }
        });
        Donor_name = findViewById(R.id.user_name);
        phone_number = findViewById(R.id.user_phone);
        blood_group = findViewById(R.id.user_bloodgroup);
        address = findViewById(R.id.user_location);

    }

    public void post(View view) {

        post_as_donor();


    }

    public void post_as_donor()
    {
        sessionManager = new SessionManager(this);
        sessionManager.checkLogin();
        HashMap<String, String> user = sessionManager.getUserDetail();
        String nEmail = user.get(sessionManager.EMAIL);
        String url = "http://projecttech.xyz//plasma_hero_by_khurshed/post_as_donor.php";
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(PostAsDonor.this, "Success", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(PostAsDonor.this, DeshboardActivity.class));
                finish();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(PostAsDonor.this, "Check your Internet Connection.", Toast.LENGTH_SHORT).show();
            }
        })
        {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {


                Map<String, String> stringStringMap = new HashMap<>();

                stringStringMap.put("user_name", Donor_name.getText().toString());
                stringStringMap.put("email", nEmail);
                stringStringMap.put("status", status);
                stringStringMap.put("blood_group", blood_group.getText().toString());
                stringStringMap.put("address", address.getText().toString());
                stringStringMap.put("phone_number", phone_number.getText().toString());


                //stringStringMap.put("token", token);




                return stringStringMap;
            }
        };
        requestQueue.add(stringRequest);
    }

}