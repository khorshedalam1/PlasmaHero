package com.khurshed.plasmahero;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class TermsOfService extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_terms_of_service);
    }
}