package com.khurshed.plasmahero;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class Adapter4  extends RecyclerView.Adapter<Adapter4.CustomAdapterHolder>{

    private List<Model1> arrayListModel;
    private Context context;
    SessionManager sessionManager;
    public Adapter4(List<Model1> arrayListModel, Context context) {
        this.arrayListModel = arrayListModel;
        this.context = context;
    }
    @NonNull
    @Override
    public Adapter4.CustomAdapterHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.incoming_row,parent,false);
        return new Adapter4.CustomAdapterHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Adapter4.CustomAdapterHolder holder, int position) {
        Model1 model = arrayListModel.get(position);
        holder.DonorName.setText(model.getDonorName());
        holder.blood_group.setText(model.getBlood_group());
        holder.DonorPhone.setText(model.getDonor_Phone());
        holder.date.setText(model.getDaTe());
        holder.address.setText(model.getAddress());
        holder.myName.setText(model.getMyName());
        holder.myPhone.setText(model.getMyPhone());

    }

    @Override
    public int getItemCount() {
        return arrayListModel.size();
    }

    public class CustomAdapterHolder extends RecyclerView.ViewHolder{
        TextView DonorName,blood_group,DonorPhone,date,address, myName, myPhone;
        public CustomAdapterHolder(@NonNull View itemView) {
            super(itemView);
            DonorName = itemView.findViewById(R.id.recycleUser1);
            blood_group = itemView.findViewById(R.id.recycleBlood1);
            date = itemView.findViewById(R.id.recycleStatus1);
            DonorPhone = itemView.findViewById(R.id.recyclePhone1);
            address = itemView.findViewById(R.id.recyclelocation1);
            myName = itemView.findViewById(R.id.recycleMyname);
            myPhone = itemView.findViewById(R.id.recycleMyPhone);


        }
    }
}
