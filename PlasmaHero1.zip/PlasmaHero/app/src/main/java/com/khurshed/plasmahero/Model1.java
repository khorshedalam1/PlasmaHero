package com.khurshed.plasmahero;

public class Model1 {
    String id;
    String DonorName, Blood_group, Donor_Phone, address, daTe, myName, myPhone;

    public Model1(String id, String donorName, String blood_group, String donor_Phone, String address, String daTe, String myName, String myPhone) {
        this.id = id;
        DonorName = donorName;
        Blood_group = blood_group;
        Donor_Phone = donor_Phone;
        this.address = address;
        this.daTe = daTe;
        this.myName = myName;
        this.myPhone = myPhone;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDonorName() {
        return DonorName;
    }

    public void setDonorName(String donorName) {
        DonorName = donorName;
    }

    public String getBlood_group() {
        return Blood_group;
    }

    public void setBlood_group(String blood_group) {
        Blood_group = blood_group;
    }

    public String getDonor_Phone() {
        return Donor_Phone;
    }

    public void setDonor_Phone(String donor_Phone) {
        Donor_Phone = donor_Phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getDaTe() {
        return daTe;
    }

    public void setDaTe(String daTe) {
        this.daTe = daTe;
    }

    public String getMyName() {
        return myName;
    }

    public void setMyName(String myName) {
        this.myName = myName;
    }

    public String getMyPhone() {
        return myPhone;
    }

    public void setMyPhone(String myPhone) {
        this.myPhone = myPhone;
    }
}
