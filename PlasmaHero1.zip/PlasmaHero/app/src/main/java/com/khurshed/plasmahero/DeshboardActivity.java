package com.khurshed.plasmahero;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

public class DeshboardActivity extends AppCompatActivity {

    SessionManager sessionManager;
    TextView user_email, phone, blood, name, welcome, counter, donationProcess;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deshboard);
        sessionManager = new SessionManager(this);
        sessionManager.checkLogin();

        user_email = findViewById(R.id.email);
        phone = findViewById(R.id.phone);
        blood = findViewById(R.id.bloodgroup);
        name = findViewById(R.id.user);
        welcome = findViewById(R.id.welcome);
        counter = findViewById(R.id.counter);
        donationProcess = findViewById(R.id.plasmaDonationProcess);
        donationProcess.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(DeshboardActivity.this, PlasmaDonationProcess.class));

            }
        });
        HashMap<String, String> user = sessionManager.getUserDetail();
        String email = user.get(sessionManager.EMAIL);

        user_email.setText(email);
        updateUserName();
        updatePhone();
        updateBloodGroup();
        countDonor();
    }

    public void Requestplasma(View view) {
        startActivity(new Intent(DeshboardActivity.this, requestPlasma.class));

    }

    public void becomeDonor(View view) {
        startActivity(new Intent(DeshboardActivity.this,PostAsDonor.class));

    }

    public void lookingforDonor(View view) {
        startActivity(new Intent(DeshboardActivity.this,AllDonorLists.class));


    }

    public void logoutt(View view) {
        sessionManager.logout();
    }
    public void countDonor()
    {
        String url = "http://projecttech.xyz/plasma_hero_by_khurshed/donor_counter.php?";

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onResponse(String response) {
                Log.d("Res=", url);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = jsonObject.getJSONArray("Result");
                    JSONObject data = jsonArray.getJSONObject(0);

//                    data.getInt("id");
//                    data.getString("student_name");
//                    data.getString("ssc_roll");
//                    data.getString("hsc_roll");
//                    data.getString("student_reg");

                    counter.setText(data.getString("COUNT(*)"));



                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(DeshboardActivity.this, "Failed", Toast.LENGTH_SHORT).show();

            }
        });

        requestQueue.add(stringRequest);
    }

    public void updateUserName()
    {
        sessionManager = new SessionManager(this);
        sessionManager.checkLogin();
        HashMap<String, String> user = sessionManager.getUserDetail();
        String email1 = user.get(sessionManager.EMAIL);
        String url = "http://projecttech.xyz/plasma_hero_by_khurshed/update_user_name.php?email=" + email1;

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onResponse(String response) {
                Log.d("Res=", url);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = jsonObject.getJSONArray("Result");
                    JSONObject data = jsonArray.getJSONObject(0);

//                    data.getInt("id");
//                    data.getString("student_name");
//                    data.getString("ssc_roll");
//                    data.getString("hsc_roll");
//                    data.getString("student_reg");

                    name.setText(data.getString("user_name"));
                    welcome.setText(data.getString("user_name"));


                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(DeshboardActivity.this, "Failed", Toast.LENGTH_SHORT).show();

            }
        });

        requestQueue.add(stringRequest);

    }
    public void updatePhone()
    {
        sessionManager = new SessionManager(this);
        sessionManager.checkLogin();
        HashMap<String, String> user = sessionManager.getUserDetail();
        String email1 = user.get(sessionManager.EMAIL);
        String url = "http://projecttech.xyz/plasma_hero_by_khurshed/update_phone.php?email=" + email1;

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onResponse(String response) {
                Log.d("Res=", url);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = jsonObject.getJSONArray("Result");
                    JSONObject data = jsonArray.getJSONObject(0);

//                    data.getInt("id");
//                    data.getString("student_name");
//                    data.getString("ssc_roll");
//                    data.getString("hsc_roll");
//                    data.getString("student_reg");

                    phone.setText(data.getString("phone_number"));





                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(DeshboardActivity.this, "Failed", Toast.LENGTH_SHORT).show();

            }
        });

        requestQueue.add(stringRequest);

    }

    public void updateBloodGroup()
    {
        sessionManager = new SessionManager(this);
        sessionManager.checkLogin();
        HashMap<String, String> user = sessionManager.getUserDetail();
        String email1 = user.get(sessionManager.EMAIL);
        String url = "http://projecttech.xyz/plasma_hero_by_khurshed/update_blood_group.php?email=" + email1;

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onResponse(String response) {
                Log.d("Res=", url);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = jsonObject.getJSONArray("Result");
                    JSONObject data = jsonArray.getJSONObject(0);

//                    data.getInt("id");
//                    data.getString("student_name");
//                    data.getString("ssc_roll");
//                    data.getString("hsc_roll");
//                    data.getString("student_reg");

                    blood.setText(data.getString("blood_group"));


                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(DeshboardActivity.this, "Failed", Toast.LENGTH_SHORT).show();

            }
        });

        requestQueue.add(stringRequest);

    }

    public void feed(View view) {
        startActivity(new Intent(DeshboardActivity.this,MyPosts.class));


    }

    public void requests(View view) {

        startActivity(new Intent(DeshboardActivity.this,PlasmaRequests.class));
    }
}