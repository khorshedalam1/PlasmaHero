package com.khurshed.plasmahero;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MyPosts extends AppCompatActivity {
    RecyclerView recyclerView;
    SessionManager sessionManager;

    MyAdapter2 adapter2;
    List<Model> modelList2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_posts);
        modelList2 = new ArrayList<>();
        recyclerView = findViewById(R.id.recyclerView2);
        recyclerView.setAdapter(adapter2);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(MyPosts.this));
        my_posts();
    }

    public void my_posts()

    {
        sessionManager = new SessionManager(this);
        sessionManager.checkLogin();
        HashMap<String, String> user = sessionManager.getUserDetail();
        String nemail1 = user.get(sessionManager.EMAIL);
        String url="http://projecttech.xyz/plasma_hero_by_khurshed/show_user_post.php?email="+nemail1;
        Log.d("TAG", "datashow: "+url);

        RequestQueue requestQueue = Volley.newRequestQueue(MyPosts.this);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                Log.d("Res=", url);
                ;
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = jsonObject.getJSONArray("Result");
                    Log.d("TAG", "onResponse: "+jsonArray);

                    for(int i=0; i<jsonArray.length();i++){
                        JSONObject data = jsonArray.getJSONObject(i);
                        Log.d("TAG", "onResponse1: "+data);
                        modelList2.add(new Model(
                                data.getString("user_name"),
                                data.getString("email"),
                                data.getString("status"),
                                data.getString("phone_number"),
                                data.getString("blood_group"),
                                data.getString("address")
                        ));
                        //Toast.makeText(Pending.this, ""+modelList, Toast.LENGTH_SHORT).show();
                    }
                    adapter2 = new MyAdapter2(modelList2,MyPosts.this);
                    recyclerView.setAdapter(adapter2);
                    adapter2.notifyDataSetChanged();

                }catch (JSONException e){
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(MyPosts.this, "Error", Toast.LENGTH_SHORT).show();
            }
        }
        );

        requestQueue.add(stringRequest);
    }

    public void recentContacts(View view) {
        startActivity( new Intent(MyPosts.this, RecentContacts.class));
    }

    public void incommingContacts(View view) {
        startActivity(new Intent(MyPosts.this, IncomingCallHistory.class));
    }
}